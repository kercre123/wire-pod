export DEBUG_LOOGING=true
export STT_SERVICE=vosk
export VOSK_WITH_GRAMMER=true
export JDOCS_ENABLE_PINGER=false
